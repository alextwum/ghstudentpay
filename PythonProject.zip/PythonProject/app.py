import tkinter as tk
from tkinter import messagebox
from datetime import datetime

# Store payments
payments_db = {}

class FeePaymentApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Fee Payment System")
        self.root.geometry("600x650")
        self.root.configure(bg="black")
        self.main_screen()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def center_frame(self):
        frame = tk.Frame(self.root, bg="black")
        frame.place(relx=0.5, rely=0.5, anchor="center")
        return frame

    def main_screen(self):
        self.clear()
        frame = self.center_frame()

        tk.Label(frame, text="GH School - Fee Payment", fg="white", bg="black", font=("Arial", 24)).pack(pady=20)
        tk.Button(frame, text="Make Payment", command=self.payment_screen, font=("Arial", 16), bg="green", fg="white", width=25).pack(pady=10)
        tk.Button(frame, text="View All Payments", command=self.view_payments, font=("Arial", 16), bg="blue", fg="white", width=25).pack(pady=10)

    def payment_screen(self):
        self.clear()
        frame = self.center_frame()

        tk.Label(frame, text="Student Fee Payment", fg="white", bg="black", font=("Arial", 20)).pack(pady=10)

        self.entries = {}

        fields = [
            ("Student ID", "sid"),
            ("Full Name", "name"),
            ("Level", "level"),
            ("Department", "department"),
            ("Contact", "contact"),
            ("Amount (GHS)", "amount")
        ]

        for label, key in fields:
            tk.Label(frame, text=label, fg="white", bg="black", font=("Arial", 16)).pack()
            entry = tk.Entry(frame, font=("Arial", 14), width=30)
            entry.pack(pady=5)
            self.entries[key] = entry

        tk.Button(frame, text="Submit Payment", command=self.save_payment, font=("Arial", 14), bg="green", fg="white").pack(pady=15)
        tk.Button(frame, text="Back", command=self.main_screen, font=("Arial", 14), bg="red", fg="white").pack()

    def save_payment(self):
        data = {key: entry.get().strip() for key, entry in self.entries.items()}

        if not all(data.values()):
            messagebox.showerror("Error", "All fields are required.")
            return

        if not data["amount"].isdigit():
            messagebox.showerror("Error", "Amount must be a number.")
            return

        # Add timestamp
        data["date"] = datetime.now().strftime("%Y-%m-%d %H:%M")

        payments_db[data["sid"]] = data
        messagebox.showinfo("Success", f"Payment of GHS {data['amount']} received from {data['name']}")
        self.main_screen()

    def view_payments(self):
        self.clear()
        frame = self.center_frame()

        tk.Label(frame, text="All Payments", fg="white", bg="black", font=("Arial", 20)).pack(pady=10)

        if not payments_db:
            tk.Label(frame, text="No payments yet.", fg="gray", bg="black", font=("Arial", 16)).pack(pady=10)
        else:
            for sid, info in payments_db.items():
                info_text = (
                    f"{info['sid']} - {info['name']}\n"
                    f"Level: {info['level']}, Dept: {info['department']}\n"
                    f"Contact: {info['contact']}, Amount: GHS {info['amount']}\n"
                    f"Date: {info['date']}"
                )
                tk.Label(frame, text=info_text, fg="white", bg="black", font=("Arial", 12), justify="left").pack(pady=10)

        tk.Button(frame, text="Back", command=self.main_screen, font=("Arial", 14), bg="red", fg="white").pack(pady=20)

# Run the app
root = tk.Tk()
app = FeePaymentApp(root)
root.mainloop()
